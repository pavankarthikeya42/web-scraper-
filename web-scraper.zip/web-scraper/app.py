from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from bs4 import BeautifulSoup
import requests
from PyPDF2 import PdfReader
from io import BytesIO
import docx
import re
app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  
@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static', 'favicon'),
                           'karthikeya_fr_favicon.png', mimetype='image/vnd.microsoft.icon')
@app.route('/')
def welcome():
    """Render the welcome screen"""
    return render_template('welcome.html')

@app.route('/enter', methods=['POST'])
def enter_site():
    """Handle welcome screen click"""
    return redirect(url_for('home'))

@app.route('/home')
def home():
    """Render the main home page"""
    return render_template('home.html')

@app.route('/scrape_website', methods=['GET', 'POST'])
def scrape_website():
    if request.method == 'POST':
        url = request.form.get('url')
        if not url:
            flash('Please enter a valid URL', 'error')
            return redirect(url_for('scrape_website'))

        try:
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()  
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            title = soup.title.string if soup.title else 'No title available'
            

            meta_description = soup.find('meta', attrs={'name': 'description'})
            description = meta_description['content'] if meta_description else 'No description available'
            
            paragraphs = []
            for p in soup.find_all('p'):
                text = clean_text(p.get_text())
                if text and len(text.split()) > 3:  
                    paragraphs.append(text)
            
            if not paragraphs:
                for div in soup.find_all('div'):
                    text = clean_text(div.get_text())
                    if text and len(text.split()) > 5:
                        paragraphs.append(text)
                        if len(paragraphs) > 10:  
                            break
            
            if not paragraphs:
                paragraphs = ['No readable paragraph content found on this page']
            
            return render_template('result.html', 
                data={
                    'type': 'Webpage',
                    'title': title,
                    'description': description,
                    'content': paragraphs[:50]  
                })
                
        except requests.exceptions.RequestException as e:
            flash(f'Error accessing URL: {str(e)}', 'error')
        except Exception as e:
            flash(f'Error scraping content: {str(e)}', 'error')
        
        return redirect(url_for('scrape_website'))
    
    return render_template('scrape_website.html')

@app.route('/scrape_document', methods=['GET', 'POST'])
def scrape_document():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(url_for('scrape_document'))
            
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(url_for('scrape_document'))

        try:
            content = file.read()
            
            if file.filename.lower().endswith('.pdf'):
                paragraphs = extract_pdf_text(content)
                file_type = 'PDF Document'
            elif file.filename.lower().endswith('.docx'):
                paragraphs = extract_word_text(content)
                file_type = 'Word Document'
            else:
                flash('Only PDF and Word documents are supported', 'error')
                return redirect(url_for('scrape_document'))
            
            if not paragraphs:
                paragraphs = ['No readable content found in document']
            
            return render_template('result.html', 
                data={
                    'type': file_type,
                    'content': paragraphs[:100]  
                })
                
        except Exception as e:
            flash(f'Error processing document: {str(e)}', 'error')
            return redirect(url_for('scrape_document'))
    
    return render_template('scrape_document.html')

def clean_text(text):
    """Clean and normalize text"""
    text = re.sub(r'\s+', ' ', text)  
    text = text.strip()
    return text

def extract_pdf_text(pdf_content):
    """Extract text from PDF with paragraph detection"""
    try:
        reader = PdfReader(BytesIO(pdf_content))
        paragraphs = []
        
        for page in reader.pages:
            text = page.extract_text()
            if text:
                page_paragraphs = [
                    clean_text(p) for p in re.split(r'\n\s*\n|\n {2,}', text) 
                    if clean_text(p)
                ]
                paragraphs.extend(page_paragraphs)
        
        return paragraphs
    
    except Exception as e:
        return [f'Error extracting PDF content: {str(e)}']

def extract_word_text(word_content):
    """Extract text from Word document preserving paragraphs"""
    try:
        doc = docx.Document(BytesIO(word_content))
        paragraphs = []
        
        for para in doc.paragraphs:
            text = clean_text(para.text)
            if text:
                paragraphs.append(text)
        
        return paragraphs
    
    except Exception as e:
        return [f'Error extracting Word content: {str(e)}']

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)